#include "syscall.h"

int
main()
{
    #if 1
	int a = GetChar();
	PutChar(a); // only to test if getchar has worked
	#endif
    return 0;
}
