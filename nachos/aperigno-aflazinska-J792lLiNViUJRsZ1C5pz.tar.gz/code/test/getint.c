#include "syscall.h"
#include <limits.h>

int main()
{
#if 1
    int i;
    GetInt(&i);
    PutInt(i);
    PutChar('\n');
#endif
    return 0;
}
