#ifdef CHANGED
#define MAX_SEMAPHORE 200
#include "synch.h"
class usersemaphore : dontcopythis
{
public:

private:
    
};
extern int Semaphore_Init(int value);

extern int Semaphore_P(int id);

extern int Semaphore_V(int id);

#endif // CHANGED
